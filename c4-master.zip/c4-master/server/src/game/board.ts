import { BoardBase } from '@kenrick95/c4'

export class ServerBoard extends BoardBase {}
